"""
    This file is a helper module for response program (T3INF9004: Cryptanalysis und Method-Audit).

    License: CC-0
    Authors: DHBW Students 200374 & 200357 (2022)
"""

# colors
ansi_red = "\x1b[91m"
ansi_green = "\x1b[92m"
ansi_white = "\x1b[97m"
ansi_blue = "\x1b[96m"
ansi_gray = "\x1b[37m"

# reset
ansi_reset = "\x1b[0m"
